// imagens e som do jogo

let imagemDaEstrada;
let imagemDoAtor;
let imagemCarro;
let imagemCarro2;
let imagemCarro3;

// soma do jogo

let somDaTrilha;
let somDaColisao;
let somDoPonto;


function preload(){
  imagemDaEstrada = loadImage("imagens/estrada1.png");
  imagemDoAtor = loadImage("imagens/amongus.png");
  imagemCarro = loadImage("imagens/tron_W.png");
  imagemCarro2 = loadImage("imagens/car2_spr.png");
  imagemCarro3 = loadImage("imagens/car4_spr.png");
  imagemCarro4 = loadImage("imagens/car3_spr-1.png");
  imagemCarro5 = loadImage("imagens/sport-car.png");
  imagemCarro6 = loadImage("imagens/tron1_blue.png");
  
  imagemCarros = [imagemCarro, imagemCarro2, imagemCarro3,imagemCarro5, imagemCarro4, imagemCarro6];
  
  
 somDaTrilha = loadSound("sons/amongSom.mp3");
 somDaColisao = loadSound("sons/cavalo.mp3");
 somDoPonto = loadSound("sons/eleGosta.mp3");
}